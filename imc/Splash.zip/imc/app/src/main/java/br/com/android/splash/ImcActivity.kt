package br.com.android.splash

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ImcActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imc)
    }
}
